import React from 'react';

interface TranscriptSegment {
  id: string;
  speaker: string;
  text: string;
  startTime: number;
  endTime: number;
}

interface TranscriptDisplayProps {
  transcript: TranscriptSegment[];
  onSegmentClick: (time: number) => void;
}

const TranscriptDisplay: React.FC<TranscriptDisplayProps> = ({ transcript, onSegmentClick }) => {
  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-h-[calc(100vh-200px)] overflow-y-auto">
      {transcript.map((segment) => (
        <div
          key={segment.id}
          className="mb-2 p-2 bg-gray-100 rounded cursor-pointer hover:bg-gray-200"
          onClick={() => onSegmentClick(segment.startTime)}
        >
          <span className="text-sm font-semibold text-gray-600">{formatTime(segment.startTime)}</span>
          <p><strong>{segment.speaker}:</strong> {segment.text}</p>
        </div>
      ))}
    </div>
  );
};

export default TranscriptDisplay;