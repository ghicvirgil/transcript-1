import React from 'react';
import { Phone } from 'lucide-react';

interface Call {
  id: string;
  topic: string;
  start_time: string;
  duration: number;
}

interface CallListProps {
  calls: Call[];
  onCallSelect: (callId: string) => void;
}

const CallList: React.FC<CallListProps> = ({ calls, onCallSelect }) => {
  return (
    <div className="bg-white shadow rounded-lg p-4">
      <h2 className="text-xl font-semibold mb-4">Calls</h2>
      <ul className="space-y-2">
        {calls.map((call) => (
          <li
            key={call.id}
            className="flex items-center p-2 hover:bg-gray-100 rounded cursor-pointer"
            onClick={() => onCallSelect(call.id)}
          >
            <Phone className="w-5 h-5 mr-2 text-blue-500" />
            <div>
              <p className="font-medium">{call.topic}</p>
              <p className="text-sm text-gray-600">
                {new Date(call.start_time).toLocaleString()} - {call.duration} min
              </p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CallList;