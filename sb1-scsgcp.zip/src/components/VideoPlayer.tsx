import React from 'react';
import ReactPlayer from 'react-player';

interface VideoPlayerProps {
  videoUrl: string;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ videoUrl }) => {
  return (
    <div className="w-full aspect-w-16 aspect-h-9">
      <ReactPlayer
        url={videoUrl}
        width="100%"
        height="100%"
        controls
      />
    </div>
  );
};

export default VideoPlayer;