import axios from 'axios';

const ASSEMBLYAI_API_KEY = import.meta.env.VITE_ASSEMBLYAI_API_KEY;
const ASSEMBLYAI_API_URL = 'https://api.assemblyai.com/v2';

interface TranscriptSegment {
  id: string;
  speaker: string;
  text: string;
  startTime: number;
  endTime: number;
}

async function createTranscriptionJob(audioUrl: string): Promise<string> {
  const response = await axios.post(
    `${ASSEMBLYAI_API_URL}/transcript`,
    { audio_url: audioUrl },
    { headers: { authorization: ASSEMBLYAI_API_KEY } }
  );
  return response.data.id;
}

async function getTranscriptionResult(transcriptId: string): Promise<any> {
  const response = await axios.get(`${ASSEMBLYAI_API_URL}/transcript/${transcriptId}`, {
    headers: { authorization: ASSEMBLYAI_API_KEY },
  });
  return response.data;
}

function convertAssemblyAIToTranscriptSegments(result: any): TranscriptSegment[] {
  if (!result.words || !Array.isArray(result.words)) {
    console.error('Unexpected result format from AssemblyAI:', result);
    throw new Error('Invalid transcription result format');
  }

  return result.words.map((word: any, index: number) => ({
    id: `${index}`,
    speaker: `Speaker ${word.speaker || 'Unknown'}`,
    text: word.text || '',
    startTime: (word.start || 0) / 1000,
    endTime: (word.end || 0) / 1000,
  }));
}

export async function transcribeAudio(audioUrl: string, updateProgress?: (progress: number) => void): Promise<TranscriptSegment[]> {
  try {
    console.log('Starting transcription for audio URL:', audioUrl);
    updateProgress?.(10);

    const transcriptId = await createTranscriptionJob(audioUrl);
    console.log('Transcription job created with ID:', transcriptId);
    updateProgress?.(20);

    let result;
    let status = 'queued';
    while (status !== 'completed' && status !== 'error') {
      await new Promise(resolve => setTimeout(resolve, 5000)); // Wait for 5 seconds before checking again
      result = await getTranscriptionResult(transcriptId);
      status = result.status;
      console.log('Transcription status:', status);
      updateProgress?.(Math.min(90, 20 + (result.percent_complete || 0)));
    }

    if (status === 'error') {
      throw new Error(`Transcription failed: ${result.error}`);
    }

    console.log('Transcription completed successfully');
    updateProgress?.(95);
    const segments = convertAssemblyAIToTranscriptSegments(result);
    console.log('Converted segments:', segments);
    updateProgress?.(100);
    return segments;
  } catch (error) {
    console.error('Error in transcribeAudio:', error);
    throw error;
  }
}