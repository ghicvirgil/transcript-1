import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export async function initializeDatabase() {
  try {
    // Check if we can connect to the database
    const { data, error } = await supabase.from('calls').select('id').limit(1);
    
    if (error) {
      if (error.code === '42501') {
        console.error('Permission denied. Please check your Supabase permissions.');
        throw new Error('Permission denied. Please check your Supabase permissions.');
      } else {
        console.error('Error connecting to the database:', error);
        throw error;
      }
    }

    console.log('Successfully connected to the database');
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
}

export async function fetchCalls() {
  try {
    const { data, error } = await supabase
      .from('calls')
      .select('*')
      .order('start_time', { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching calls:', error);
    throw error;
  }
}