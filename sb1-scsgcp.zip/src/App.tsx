import React, { useState, useEffect } from 'react';
import VideoUploader from './components/VideoUploader';
import VideoPlayer from './components/VideoPlayer';
import TranscriptDisplay from './components/TranscriptDisplay';
import CallList from './components/CallList';
import { initializeDatabase, fetchCalls } from './utils/supabase';
import { transcribeAudio } from './utils/assemblyai';

interface Call {
  id: string;
  topic: string;
  start_time: string;
  duration: number;
  video_url: string;
}

interface TranscriptSegment {
  id: string;
  speaker: string;
  text: string;
  startTime: number;
  endTime: number;
}

function App() {
  const [calls, setCalls] = useState<Call[]>([]);
  const [selectedCall, setSelectedCall] = useState<Call | null>(null);
  const [transcript, setTranscript] = useState<TranscriptSegment[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function init() {
      try {
        await initializeDatabase();
        const fetchedCalls = await fetchCalls();
        setCalls(fetchedCalls);
      } catch (error) {
        console.error('Error during initialization:', error);
        setError('There was an error initializing the app. Please try refreshing the page or check your internet connection.');
      }
    }
    init();
  }, []);

  const handleUploadComplete = async (videoUrl: string) => {
    try {
      const newCall: Call = {
        id: Date.now().toString(),
        topic: 'New Call',
        start_time: new Date().toISOString(),
        duration: 0,
        video_url: videoUrl,
      };
      setCalls([newCall, ...calls]);
      setSelectedCall(newCall);
      
      const segments = await transcribeAudio(videoUrl);
      setTranscript(segments);
    } catch (error) {
      console.error('Error processing uploaded video:', error);
      setError('There was an error processing the uploaded video. Please try again.');
    }
  };

  const handleCallSelect = async (callId: string) => {
    const selected = calls.find(call => call.id === callId);
    if (selected) {
      setSelectedCall(selected);
      setTranscript([]); // Clear previous transcript
      
      try {
        const segments = await transcribeAudio(selected.video_url);
        setTranscript(segments);
      } catch (error) {
        console.error('Error fetching transcript:', error);
        setError('There was an error fetching the transcript. Please try again later.');
      }
    }
  };

  const handleSegmentClick = (time: number) => {
    // Implement seek functionality if needed
  };

  if (error) {
    return <div className="text-red-500 p-4">{error}</div>;
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">Video Transcription App</h1>
      <div className="grid grid-cols-3 gap-4">
        <div>
          <CallList calls={calls} onCallSelect={handleCallSelect} />
          <VideoUploader onUploadComplete={handleUploadComplete} />
        </div>
        <div>
          {selectedCall && (
            <VideoPlayer videoUrl={selectedCall.video_url} />
          )}
        </div>
        <div>
          <TranscriptDisplay transcript={transcript} onSegmentClick={handleSegmentClick} />
        </div>
      </div>
    </div>
  );
}

export default App;